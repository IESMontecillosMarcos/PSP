/*
	
	Cliente UDP
	cliente [IP Servidor] [Puerto] [Comando|Mensaje]

	Marcos Gonzalez Leon
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>
#include <string.h>
#include <stdbool.h>

// Tabla de Errores.
#define ERR_NOSOCKET -1
#define ERR_NOBIND -2

#define TAM_BUFFER 1024

int main(int argc, char **argv){

	// Vars.
	int sock;
	struct sockaddr_in name;
	struct hostent *host;

	if (argc != 4){
		printf("Error, Sintaxis incorrecta: Cliente IP Puerto Comando\n");
		return -1;
	}

	// Abre socket.
	sock = socket(PF_INET,SOCK_DGRAM,0);
	if (sock < 0){
		printf("Error al crear socket.\n");
		return -2;
	}

	// Comprobar que el servidor esta operativo
	host = gethostbyname(argv[1]);
	if (host == NULL){
		printf("Servidor desconocido.\n");
		return -3;
	}

	// Datos de conexion del socket.
	memcpy((char *) &name.sin_addr,host->h_addr,host->h_length);
	name.sin_family = AF_INET;
	name.sin_port = htons(atoi(argv[2]));

	// Envia datos.
	if (sendto(sock,argv[3],strlen(argv[3]),0,(struct sockaddr *) &name,sizeof(name)) < 0){
		printf("Error al enviar.\n");
	} else {
		printf("Envio correcto.\n");
	}

	close(sock);

	return 0;
}