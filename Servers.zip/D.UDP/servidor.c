/*
	
	Servidor UDP
	Diagramas
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>
#include <string.h>
#include <stdbool.h>

// Tabla de Errores.
#define ERR_NOSOCKET -1
#define ERR_NOBIND -2

#define TAM_BUFFER 1024
#define SERVER_NAME "myserver"

int main(void){

	// Vars,
	int sock;
	struct sockaddr_in name;
	int port = 1500;
	int socket_len;
	char buffer[TAM_BUFFER];
	bool ok;
	int longitud;


	// Start of program.

	// Crear el socket.
	sock = socket(PF_INET,SOCK_DGRAM,0);
	if (sock<0){
		printf("Error al crear socket.\n");
		return -1;
	}

	// Datos de conexion.
	name.sin_family = AF_INET;

	// Direcion local.
	name.sin_addr.s_addr = htonl(INADDR_ANY);
	//name.sin_addr.s_addr = inet_addr("192.168.100.18");
	name.sin_port = htons(port);

	// Asocia las propiedades de conexion al socket.
	if (bind(sock,(struct sockaddr *) &name,sizeof(name)) < 0){
		printf("Error en el bind.\n");
		return -2;
	}

	// Obtiene el nombre del servidor.
	socket_len = sizeof(name);

	if (getsockname(sock,(struct  sockaddr *) &name,(socklen_t *) &socket_len) < 0){
		printf("Error al obtener el nombre del socket.\n");
		return -3;
	}

	// Servidor funcionando.
	printf("Servidor ...\n");
	//printf("IP: %s\n",inet_ntoa(name.sin_addr)); Falla al cargar la IP
	printf("Port: %d\n",ntohs(name.sin_port));

	// Ciclo de server.
	ok = true;
	while(ok){

		// Limpiar buffer.
		//strcpy(buffer,"");
		memcpy(buffer,"",TAM_BUFFER);

		// Lectura UDP.
		if (recvfrom(sock,buffer,TAM_BUFFER,0,(struct sockaddr *) NULL,(socklen_t *) &longitud) < 0){
			printf("Error al recibir datos.\n");
		} else {
			printf ("Datos recibidos:\n");
			printf ("%s\n",buffer);

			// PENDIENTE. ACTIVIDADEs
			// - Comandos:
			/*
				Mensaje -> Muestra.
				Comando -> Accion:
					[EXIT] -> Parar
			*/

			if (strcmp(buffer,"[EXIT]") == 0){
				ok = false;
			}
		}
	}

	// Cierra socket.
	close(sock);

	return 0;
}