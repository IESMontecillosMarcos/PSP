/*

	Marcos Gonzalez Leon
	PSP Libreria INI


*/

#ifndef HEADER_FILE
#define HEADER_FILE

#include <stdio.h>

// Prototipos.
int readIniString(char *inifile,char *seccion,char *clave, char *valor);
int readIniInt(char *inifile,char *seccion,char *clave,int *valor);
int readInitDouble(char *inifile,char *seccion,char *clave,double *valor);
void libLoadSuccess();	// Mensaje de libreria cargada.

#endif

