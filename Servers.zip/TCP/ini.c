/*

	Marcos Gonzalez Leon
	PSP Libreria INI


*/

#include "ini.h"



int main(void){

	// Vars.


	// Start of Program.
	libLoadSuccess();

	return 0;
}

void libLoadSuccess(){
	printf("Libreria cargada!\n");
}

int readIniString(char *inifile,char *seccion,char *clave, char *valor){
	return -1;
}