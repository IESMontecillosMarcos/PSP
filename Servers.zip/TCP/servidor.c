/*
	Marcos Gonzalez Leon
	PSP
	Servidor TCP
	Diagramas
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include "liblog.a"	// Solucion temporal.
//#include "log.h"	// Solucion temporal.

// Tabla de Errores.
#define ERR_NOSOCKET -1
#define ERR_NOBIND -2
#define ERR_NOCON -3

#define TAM_BUFFER 1024
#define PORT 2800
#define SERVER_NAME "myserver"



int main(void){

	// FALTA POR IMPLEMENTAR:
	// - Fichero log. enlazado.
	// - Fichero INI, enlazado.
	// - Mensaje de respuesta a cliente.
	// - Conversion de Double a Char* en funciones Log

	// ERRORES CONOCIDOS:
	// Linkado de librerias, no funciona o algo.



	// Vars,
	int socksrv;	// Escucha conexiones de cliente.
	int sockdata;	// Envia datos al cliente.
	int datos_leidos;

	int command_result;

	struct sockaddr_in name;
	char buffer[TAM_BUFFER];

	char *f = "serv.log";
	char date[20];
	struct tm *sTm;

	char srv_command[70];

	bool ok;

	// TEST AREA:
	//readIniString("config.ini","[NETWORK]","yes","ok");

	// ----------------

	// START OF PROGRAM

	logLoadSuccess();


	time_t now = time (0);
	sTm = gmtime (&now);
	strftime (date, sizeof(date), "%Y-%m-%d %H:%M:%S", sTm);

	// Log Write.
	strcpy(srv_command,"");
	strncpy(srv_command,date,sizeof(srv_command));
	strncat(srv_command," Server Cold Start Initializing...",38);
	writeLogMsg(f,2,srv_command);


	// Abre sockets de escucha.
	socksrv = socket(PF_INET,SOCK_STREAM,0);
	if (socksrv < 0){
		/// Log Write.
		strcpy(srv_command,"");
		strncpy(srv_command,date,sizeof(srv_command));
		strncat(srv_command," ERR_NOSOCKET ",38);
		writeLogMsg(f,0,srv_command);
		//printf("Error al crear socket de esucha.\n");
		return ERR_NOSOCKET;
	}


	// Parametros del socket.
	name.sin_family = AF_INET;
	name.sin_addr.s_addr = htonl(INADDR_ANY);
	name.sin_port = htons(PORT);

	// Imprime los parametros del servidor.
	// IP, Puerto

	// Asocia los parametros de conexion al socket servdor.

	if (bind(socksrv, (struct sockaddr *) &name,sizeof(name))){
		// Log Write.
		strcpy(srv_command,"");
		strncpy(srv_command,date,sizeof(srv_command));
		strncat(srv_command," ERR_NOBIND",38);
		writeLogMsg(f,0,srv_command);
		//printf("Error en el bind.\n");
		return ERR_NOBIND;
	}

	// POnemos el socketsrv en modo escucha
	listen(socksrv,1);

	// Servidor funcionando.
	printf("Servidor ...\n");
	printf("IP: %s\n",inet_ntoa(name.sin_addr));
	// strcpy(srv_ip,inet_aton(name.sin_addr)); NON Functional Yet.
	printf("Port: %d\n",ntohs(name.sin_port));

	

	// Log Write.
	strcpy(srv_command,"");
	strncpy(srv_command,date,sizeof(srv_command));
	strncat(srv_command," Server Start Executed...",38);
	writeLogMsg(f,2,srv_command);

	// ciclo de funcionamiento del servidor
	ok = true;
	while(ok){

		// Log Write.
		strcpy(srv_command,"");
		strncpy(srv_command,date,sizeof(srv_command));
		strncat(srv_command," Server Sleeping..",38);
		writeLogMsg(f,2,srv_command);

		printf("Esperando conexiones.\n");
		
		//strcpy(buffer,"");

		// Tratamiento de conexion entrante.
		sockdata = accept(socksrv, (struct sockaddr *) NULL, (socklen_t *) NULL);

		if (sockdata < 0){
			// Log Write.
			strcpy(srv_command,"");
			strncpy(srv_command,date,sizeof(srv_command));
			strncat(srv_command," ERR_NOCON",38);
			writeLogMsg(f,0,srv_command);
			//printf("Error en conexion con cliente.\n");
			return ERR_NOCON;		
		} else {
			// Lee los datos del socket.
			datos_leidos = read(sockdata,buffer,TAM_BUFFER);
			if (datos_leidos < 0){
				// Log Write.
				strcpy(srv_command,"");
				strncpy(srv_command,date,sizeof(srv_command));
				strncat(srv_command," Error en lectura de datos cliente",38);
				writeLogMsg(f,0,srv_command);
				//printf("Error de lectura de datos cliente.\n");

			} else {
				printf("Conexion con cliente establecida...\n");

				// Envia cosas al cliente.
				printf("Datos : %s\n",buffer );


				time_t now = time (0);
    			sTm = gmtime (&now);
    			strftime (date, sizeof(date), "%Y-%m-%d %H:%M:%S", sTm);


				// COMANDOS DE SERVIDOR
				// =================================
				if (strcmp(buffer,"[EXIT]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [EXIT] ",38);
					writeLogMsg(f,3,srv_command);
					
					ok = false;
					
				} else if (strcmp(buffer,"[TIME]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [TIME] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said TIME Command.\n");
					command_result = system("date +'%T'");
					if (command_result<0){
						// Log Write.
						strcpy(srv_command,"");
						strncpy(srv_command,date,sizeof(srv_command));
						strncat(srv_command," [TIME] Failed Exec",38);
						writeLogMsg(f,0,srv_command);
						// A mirar el log ahora
						//printf("Command execution has failed.\n");
					}
				} else if (strcmp(buffer,"[DATE]") == 0){
					
					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [DATE] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said DATE Command.\n");
					command_result = system("date +'%D'");
					if (command_result<0){
						// Log Write.
						strcpy(srv_command,"");
						strncpy(srv_command,date,sizeof(srv_command));
						strncat(srv_command," [DATE] Failed Exec",38);
						writeLogMsg(f,0,srv_command);
						// A mirar el log ahora
						//printf("Command execution has failed.\n");
					}
				} else if (strcmp(buffer,"[USER]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [USER] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said USER Command.\n");
					command_result = system("cut -d: -f1 /etc/passwd");
					if (command_result<0){
						// Log Write.
						strcpy(srv_command,"");
						strncpy(srv_command,date,sizeof(srv_command));
						strncat(srv_command," [USER] Failed Exec",38);
						writeLogMsg(f,0,srv_command);
						// A mirar el log ahora
						//printf("Command execution has failed.\n");
					}
				} else if (strcmp(buffer,"[PROC]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [PROC] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said PROC Command.\n");
					command_result = system("ps aux | wc -l");
					if (command_result<0){
						// Log Write.
						strcpy(srv_command,"");
						strncpy(srv_command,date,sizeof(srv_command));
						strncat(srv_command," [PROC] Failed Exec",38);
						writeLogMsg(f,0,srv_command);
						// A mirar el log ahora
						//printf("Command execution has failed.\n");
					}
				} else if (strcmp(buffer,"[UPTIME]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [UPTIME] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said UPTIME Command.\n");
					command_result = system("uptime -p");
					if (command_result<0){
						// Log Write.
						strcpy(srv_command,"");
						strncpy(srv_command,date,sizeof(srv_command));
						strncat(srv_command," [UPTIME] Failed Exec",38);
						writeLogMsg(f,0,srv_command);
						// A mirar el log ahora
						//printf("Command execution has failed.\n");
					}
				} else if(strcmp(buffer,"[CPUTEMP]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [CPUTEMP] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said CPUTEMP Command.\n");
					command_result = system("sensors | grep core");
					if (command_result<0){
						// Log Write.
						strcpy(srv_command,"");
						strncpy(srv_command,date,sizeof(srv_command));
						strncat(srv_command," [CPUTEMP] Failed Exec",38);
						writeLogMsg(f,0,srv_command);
						// A mirar el log ahora
						//printf("Command execution has failed.\n");
					}
				} else if (strcmp(buffer,"[HELP]") == 0){

					// Log Write.
					strcpy(srv_command,"");
					strncpy(srv_command,date,sizeof(srv_command));
					strncat(srv_command," [HELP] ",38);
					writeLogMsg(f,3,srv_command);

					printf("User said Help ME!\n");
					printf(">> Mostrando Comandos... \n");
					printf(">> [HELP]\n");
					printf(">> [TIME]\n");
					printf(">> [DATE]\n");
					printf(">> [USER]\n");
					printf(">> [PROC]\n");
					printf(">> [UPTIME]\n");
					printf(">> [CPUTEMP]\n");
					printf(">> [EXIT]\n");		

					if (write(sockdata,"hola",4) < 0){
						printf("Error de transmision.\n");
					} else {
						printf("Datos enviados correctamente.\n");
					}


				}
				// ============================

				// Limpiar Buffer
				memset(buffer,'\0',TAM_BUFFER);

			}
			printf("Cierra conexion con el cliente.\n");
			close(sockdata);
		}
	}

	// Log Write.
	strcpy(srv_command,"");
	strncpy(srv_command,date,sizeof(srv_command));
	strncat(srv_command," Server Shutdown...",38);
	writeLogMsg(f,2,srv_command);
	close(socksrv);	

	return 0;
}


// SOLUCION TEMPORAL A LIBRERIA LOG
/*

void writeLogMsg(char *file,int tipo, char *msg){
	
	FILE *in_fd = fopen(file, "a"); // OPens file for append (Adds lines to the existin ones(?))

	if (in_fd == NULL){
		printf("Error al abrir fichero Log.\n");		
	} else {

		switch(tipo){
			case 0:
				fputs("[ERROR] ",in_fd);
				fputs(msg,in_fd);
			break;
			case 1:
				fputs("[WARNING] ",in_fd);
				fputs(msg,in_fd);
			break;
			case 2:
				fputs("[INFO] ",in_fd);
				fputs(msg,in_fd);
			break;
			case 3:
				fputs("[COMMAND_EXEC] ",in_fd);
				fputs(msg,in_fd);
			break;
			default:
				fputs("[UNKNOWN_TYPE] ",in_fd);
		}

		fputs("\n",in_fd);
		fclose(in_fd);
	}	
}

void writeLogInt(char *file,int tipo, char *msg,int n){
	
	FILE *in_fd = fopen(file, "a"); // OPens file for append (Adds lines to the existin ones(?))

	if (in_fd == NULL){
		printf("Error al abrir fichero Log.\n");		
	} else {

		switch(tipo){
			case 0:
				fputs("[ERROR] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			case 1:
				fputs("[WARNING] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			case 2:
				fputs("[INFO] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			case 3:
				fputs("[COMMAND_EXEC] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			default:
				fputs("[UNKNOWN_TYPE] ",in_fd);
		}

		fputs("\n",in_fd);
		fclose(in_fd);
	}	
}

void writeLogDouble(char *file,int tipo, char *msg,double n){
	
	FILE *in_fd = fopen(file, "a"); // OPens file for append (Adds lines to the existin ones(?))

	if (in_fd == NULL){
		printf("Error al abrir fichero Log.\n");		
	} else {

		switch(tipo){
			case 0:
				fputs("[ERROR] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			case 1:
				fputs("[WARNING] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			case 2:
				fputs("[INFO] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			case 3:
				fputs("[COMMAND_EXEC] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			default:
				fputs("[UNKNOWN_TYPE] ",in_fd);
		}

		fputs("\n",in_fd);
		fclose(in_fd);
	}	
}

// Comprobacion de carga de metodos desde la aplicacion principal.
void logLoadSuccess(){	
	printf("Libreria Log cargada con exito!\n");
}
*/

// SOLUCION TEMPORAL A LIBRERIA INI

void readIniString(char *inifile,char *seccion,char *clave,char *valor){

	// Leer linea por linea hasta fin de fichero.
	// Comparar cada linea con la seccion.
		// Buscar claves dentro de la seccion.

	// Errores por aqui. Ultima dia, prueba con cadenas y punteros (revisar)


	char *config="";
	char keyvalue[20];

	fgets(keyvalue,sizeof(keyvalue),inifile);

	do {		
		if (keyvalue!= NULL){
			if (strcmp(keyvalue,seccion)==0){
				printf("Seccion encontrada! %s\n",keyvalue);
			} else {
				printf("Seccion no encontrada!\n");
			}
		}
	}
	while (fgets(keyvalue,sizeof(keyvalue),inifile)!= NULL);
	//return config;

}

int readIniInt(char *inifile,char *seccion,char *clave,int *valor){
	return -1;

}

double readIniDouble(char *inifile,char *seccion,char *clave,double *valor){
	return -1;
}