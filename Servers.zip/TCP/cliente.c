/*
	Marcos Gonzalez Leon
	PSP
	Cliente TCP
	Diagramas
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>
#include <string.h>
#include <stdbool.h>

// Tabla de Errores.
#define ERR_NOSOCKET -1
#define ERR_NOBIND -2

#define TAM_BUFFER 1024

int main(int argc,char **argv){

	// vars.
	int sock;					// Envia datos al server.
	int sockdata;				// Recibir datos del server.
	int datos_leidos;

	char buffer[TAM_BUFFER];
	//bool ok;

	struct sockaddr_in name;
	//struct sockaddr_in srv;
	struct hostent *host;

	// Control de argumentos.
	if (argc != 4){
		printf("Error, Numero de argumentos erroneo.\n");
		return -3;
	}


	// Abre el socket.
	sock = socket(PF_INET,SOCK_STREAM,0);
	if (sock < 0){
		printf("Error, al crear socket.");
		return ERR_NOSOCKET;
	}

	// Abre sockets de escucha.
	/*
	socksrv = socket(PF_INET,SOCK_STREAM,0);
	if (socksrv < 0){
		printf("Error al crear socket de esucha.\n");
		return ERR_NOSOCKET;
	}
	*/


	// Rellena los parametros de conexion del socket.
	name.sin_family = AF_INET;
	name.sin_port = htons(atoi(argv[2]));

	// Servidor existe?
	host = gethostbyname(argv[1]);

	if (host == NULL){
		printf("Error, servidor desconocido.\n");
		return ERR_NOBIND;
	}

	// Copia la direccion del servidor en los parametros
	memcpy((char *) &name.sin_addr, (char *) host->h_addr,host->h_length);

	// Asocia los parametros de conexion al socket servdor.
	/*
	if (bind(socksrv, (struct sockaddr *) &name,sizeof(name))){
		printf("Error en el bind.\n");
		return ERR_NOBIND;
	}*/

	// POnemos el socketsrv en modo escucha
	//listen(socksrv,1);


	// Conexion -> Envio trama de descubrimiento que crea circuito virtual
	if (connect(sock,(struct sockaddr *) &name, sizeof(name)) < 0){
		printf("Error, Servidor ha rechazado la conexion.\n");
	} else {
		// Conexion acceptada.
		// Ha derivado al socket de datos -> envia datos
		if (write(sock,argv[3],strlen(argv[3])) < 0){
			printf("Error de transmision.\n");
		} else {
			printf("Datos enviados correctamente.\n");


			// Y AHORA TOCAR ESPERAR LA RESPUESTA DEL SERVER.
			sockdata = accept(sock, (struct sockaddr *) NULL, (socklen_t *) NULL);

			if (sockdata<0){
				printf("Error en respuesta del servidor.\n");	
				return -10;
			} else {
				// Lee los datos del socket.
				datos_leidos = read(sockdata,buffer,TAM_BUFFER);
				if (datos_leidos<0){
					printf("Error de lectura de datos cliente.\n");					

				} else {
					printf("Conexion con servidor establecida...\n");

				}
				close(sockdata);
			}
		}		
	}
	close(sock);
	//close(socksrv);

	return 0;
}