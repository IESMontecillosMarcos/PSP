/*

	Marcos Gonzalez Leon
	PSP Libreria LOG


*/

#include "log.h"

/*
int main(void){
	


	return 0;
}
*/

void writeLogMsg(char *file,int tipo, char *msg){
	
	FILE *in_fd = fopen(file, "a"); // OPens file for append (Adds lines to the existin ones(?))

	if (in_fd == NULL){
		printf("Error al abrir fichero Log.\n");		
	} else {

		switch(tipo){
			case 0:
				fputs("[ERROR] ",in_fd);
				fputs(msg,in_fd);
			break;
			case 1:
				fputs("[WARNING] ",in_fd);
				fputs(msg,in_fd);
			break;
			case 2:
				fputs("[INFO] ",in_fd);
				fputs(msg,in_fd);
			break;
			case 3:
				fputs("[COMMAND_EXEC] ",in_fd);
				fputs(msg,in_fd);
			break;
			default:
				fputs("[UNKNOWN_TYPE] ",in_fd);
		}

		fputs("\n",in_fd);
		fclose(in_fd);
	}	
}

void writeLogInt(char *file,int tipo, char *msg,int n){
	
	FILE *in_fd = fopen(file, "a"); // OPens file for append (Adds lines to the existin ones(?))

	if (in_fd == NULL){
		printf("Error al abrir fichero Log.\n");		
	} else {

		switch(tipo){
			case 0:
				fputs("[ERROR] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			case 1:
				fputs("[WARNING] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			case 2:
				fputs("[INFO] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			case 3:
				fputs("[COMMAND_EXEC] ",in_fd);
				fputs(msg,in_fd);
				//fputs("int = ",in_fd);
				//fputs(itoa(n),in_fd);
			break;
			default:
				fputs("[UNKNOWN_TYPE] ",in_fd);
		}

		fputs("\n",in_fd);
		fclose(in_fd);
	}	
}

void writeLogDouble(char *file,int tipo, char *msg,double n){
	
	FILE *in_fd = fopen(file, "a"); // OPens file for append (Adds lines to the existin ones(?))

	if (in_fd == NULL){
		printf("Error al abrir fichero Log.\n");		
	} else {

		switch(tipo){
			case 0:
				fputs("[ERROR] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			case 1:
				fputs("[WARNING] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			case 2:
				fputs("[INFO] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			case 3:
				fputs("[COMMAND_EXEC] ",in_fd);
				fputs(msg,in_fd);
				//fputs("double = ",in_fd);
				//fputs(n,in_fd);
			break;
			default:
				fputs("[UNKNOWN_TYPE] ",in_fd);
		}

		fputs("\n",in_fd);
		fclose(in_fd);
	}	
}

// Comprobacion de carga de metodos desde la aplicacion principal.
void logLoadSuccess(){	
	printf("Libreria Log cargada con exito!\n");
}