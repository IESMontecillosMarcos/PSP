/*

	Marcos Gonzalez Leon
	PSP Libreria LOG


*/

#ifndef HEADER_FILE
#define HEADER_FILE

#define ERR_OPENLOG -10;

#include <stdio.h>

// Prototipos.
void writeLogMsg(char *file,int tipo, char *msg);
void writeLogInt(char *file,int tipo,char *msg,int n);
void writeLogDouble(char *file,int tipo, char *msg, double valor);
void logLoadSuccess();	// Mensaje de libreria cargada.

#endif