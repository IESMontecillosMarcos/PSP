/*

	DOMINIO UNIX
	COMUNIACION LOCAL

	Servidor
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <string.h>
#include <stdbool.h>

// Tabla de Errores.
#define ERR_NOSOCKET -1
#define ERR_NOBIND -2

#define TAM 1024
#define SERVER_NAME "myserver"

int main (void){
	// Descriptor socket
	int sock;
	struct sockaddr_un name;	
	char buffer[TAM];
	bool ok;

	// Crea un socket para escucha
	sock = socket(PF_UNIX,SOCK_DGRAM,0);

	if (sock < 0){
		// Error al crear el socket (por lo que sea).
		return ERR_NOSOCKET;
	}

	// Rellenamos Campos de Socket.
	name.sun_family = AF_UNIX;	// El Address Family es UNIX.
	strcpy(name.sun_path,SERVER_NAME); // Copiamos el nombre/direccion del servidor al path.

	// De esta manera sabe localizar el servidor dentro de la maquina.

	// Ahora toca enlazar con datos de conexion.

	// p1. Socket a enlazar datos.
	// p2. Donde se encuentran los datos.
	// p3. Tamanio de la estructura.
	if (bind(sock,(struct sockaddr *) &name,sizeof(name)) < 0){
		// No se ha podido enlazar.
		return ERR_NOBIND;
	}

	// Si ha sobrevivido hasta aqui, mi ehnorabuena.
	printf("Servidor: %s\n",SERVER_NAME);

	ok = true;

	while(ok){
		// Recibe datos.
		// p1. De que sockets recibe datos.
		// p2. Donde coloca esos datos del cliente
		// p3. Cuantos datos quiere leer, para no desbordarse.
		// Otros P. Asi siempre, se usan en otros protocolos, aqui no.
		if (recvfrom(sock,buffer, TAM, 0, NULL,NULL) < 0){
			printf("Error al recibir datos\n");
		} else {

			printf("Datos leidos: %s\n",buffer);

			// Testing: Reconocer Comandos.
			if (strcmp(buffer,"exit") ==0){
				ok = false;
			} else if (strcmp(buffer,"help") ==0){
				printf(">> User said Help.\n");
			} else if (strcmp(buffer,"servername") ==0){
				printf(">> %s.\n",SERVER_NAME);
			} else if (strcmp(buffer,"user") ==0){
				printf(">> User said User.\n");
			}
		}
	}
	

	// Cerramos Socket.
	close(sock);
	remove(SERVER_NAME);

	return 0;
}
