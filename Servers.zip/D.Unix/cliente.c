/*

	DOMINIO UNIX
	COMUNIACION LOCAL

	Cliente

	- Marcos Gonzalez Leon
	- PSP - 2DAM

*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <string.h>

// Tabla de Errores.
#define TAM 1024

int main (int argc, char **argv){

	// Vars.
	int sock;
	struct sockaddr_un name;
	char mensaje[] = "Mensaje enviado mediante sockets.";




	// Start of Program.
	if (argc != 3){
		printf("Error, no se ha especificado el nombre del servidor o falta comando.\n");
		return -1;
	}

	// Copiar comando pasado.
	// Abre Socket.
	sock = socket(PF_UNIX,SOCK_DGRAM,0);
	if (sock < 0){
		printf("Error al abrir el socket.\n");
		return -1;
	}

	// TOdo ok
	// Rellena los datos de la conexion.
	name.sun_family = AF_UNIX;
	strcpy(name.sun_path,argv[1]); // Le pasamos el nombre del server, el Argv[1]

	// Enviar datos.
	if(sendto(sock,argv[2],strlen(argv[2]),0,(struct sockadd *) &name,sizeof(name)) < 0){
		printf("Error en el envio de datos.\n");
	}

	// Cierra socket.
	close(sock);


	return 0;
}