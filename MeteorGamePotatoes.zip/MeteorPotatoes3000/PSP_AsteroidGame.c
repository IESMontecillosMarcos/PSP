/*
	Ejemplo 4. SDL
	Limites con el borde
	Requiere la instalación de la librería SDL1.2 (apt-get install libsdl1.2-dev)
	gcc -Wall -O2 -oejem1 ejem1.c `sdl-config --cflags --libs`

	Se pide:
        1. Aparición de meteoritos (cada uno controlado por un thread) verticales.
        2. Lanzar un número aleatorio para establecer la coordenada X en la que caerá.
        3. La nave deberá evitar el meteorito, y en caso de colisión, el juego termina.

    ADICIONAL:
        4. En caso de colisión, pintar una secuencia de explosión.
        5. Añadir capacidad de disparo a la nave.
*/

#include <stdio.h>
#include <pthread.h>
#include "SDL/SDL.h"

#define INC_HORIZONTAL 5
#define METEOR1_VELOCITY 1
#define METEOR2_VELOCITY 4
#define METEOR3_VELOCITY 2
#define METEOR4_VELOCITY 3
#define LASER_VELOCITY 2
#define TRUE 1
#define FALSE 0

struct datos_t {
	SDL_Surface asteroid;
	SDL_Surface pantallita;
	SDL_Rect rain;		// Indica la posicion del Meteorito.
	pthread_mutex_t mutex;
};

struct potatolaser_t{
	SDL_Surface asteroid;
	SDL_Surface pantallita;
	SDL_Rect laser_rect;		// Indica la posicion del laser.
	SDL_Rect ship_rect;			// Indica la posicion de la nave.
	pthread_mutex_t mutex;
};

// Funciones Threads
void *meteorito_rain1(void *);
void *meteorito_rain2(void *);
void *meteorito_rain3(void *);
void *meteorito_rain4(void *);

void *laser_shot(void *);

void borrar(SDL_Surface *pant, SDL_Rect pos);
void pintar(SDL_Surface *img, SDL_Rect pos, SDL_Surface *pant);

int main(void)
{

	/*
		Falta por Implementar:		
			- Meteoritos en Threads con Loop. Se destruyen y se crean hilos nuevos de 0.
			- Explosion e impacto?

		Errores Conocidos:
			- Num_meteoritos no se modifica. (Necesario?) Los Threads no necesitan reiniciarse por ahora...
			- El Laser solo se ejecuta si mantenemos presionada la tecla SDLK_SPACEBAR.
			- La nave huele a patatas fritas.
	*/


	// Variables.
	SDL_Surface *screen;
	SDL_Surface *imagen;

	// THREAD Meteor1
	SDL_Surface *img_meteor;
	SDL_Rect rain;
	struct datos_t datos;
	pthread_t thread_id1;

	// THREAD Meteor2.
	SDL_Surface *img_meteor2;
	SDL_Rect rain2;
	struct datos_t datos2;
	pthread_t thread_id2;

	// THREAD 3.	
	SDL_Surface *img_meteor3;
	SDL_Rect rain3;
	struct datos_t datos3;
	pthread_t thread_id3;

	// THREAD 4.
	SDL_Surface *img_meteor4;
	SDL_Rect rain4;
	struct datos_t datos4;
	pthread_t thread_id4;

	// Laser	
	SDL_Surface *laser;
	SDL_Rect laser_rect;	
	struct potatolaser_t datos_laser;
	pthread_t thread_laser;
	
	SDL_Rect dest;	
	SDL_Event evento;
	int salir = FALSE;
	int num_meteoritos=0;
	Uint8 *teclado;

	srand(time(NULL)); 

	/* Inicializa SDL */
	if(SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("Error inicializando librerias\n");
		return -1;
	}

	/* Conmuta a modo gráfico */
	screen = SDL_SetVideoMode(640, 480, 16, SDL_HWSURFACE);
	if(screen == NULL)
	{
		printf("No se puede iniciar el modo gráfico\n");
		return -2;
	}

	/* Carga una imagen en memoria */
	imagen = SDL_LoadBMP("nave.bmp");
	if(imagen == NULL)
	{
		printf("Error al cargar gráfico: %s\n", SDL_GetError());
		return -3;
	}

	/* Carga una imagen de Metoerito en memoria */
	img_meteor = SDL_LoadBMP("meteor.bmp");
	if(img_meteor == NULL)
	{
		printf("Error al cargar gráfico: %s\n", SDL_GetError());
		return -3;
	}

	/* Carga una imagen de Metoerito en memoria */
	img_meteor2 = SDL_LoadBMP("meteor2.bmp");
	if(img_meteor2 == NULL)
	{
		printf("Error al cargar gráfico: %s\n", SDL_GetError());
		return -3;
	}

	/* Carga una imagen de Metoerito en memoria */
	img_meteor3 = SDL_LoadBMP("meteor3.bmp");
	if(img_meteor3 == NULL)
	{
		printf("Error al cargar gráfico: %s\n", SDL_GetError());
		return -3;
	}

	/* Carga una imagen de Metoerito en memoria */
	img_meteor4 = SDL_LoadBMP("meteor4.bmp");
	if(img_meteor4 == NULL)
	{
		printf("Error al cargar gráfico: %s\n", SDL_GetError());
		return -3;
	}

	/* Carga una imagen de Metoerito en memoria */
	laser = SDL_LoadBMP("laser.bmp");
	if(laser == NULL)
	{
		printf("Error al cargar gráfico: %s\n", SDL_GetError());
		return -3;
	}

	// TRANSPARENCIA DE NAVE
	SDL_SetColorKey(imagen, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(imagen->format, 0, 67, 171));

	// TRANSPARENCIA DE Meteorito1
	SDL_SetColorKey(img_meteor, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(img_meteor->format, 0, 67, 171));

	// TRANSPARENCIA DE Meteorito2
	SDL_SetColorKey(img_meteor2, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(img_meteor2->format, 0, 67, 171));

	// TRANSPARENCIA DE Meteorito2
	SDL_SetColorKey(img_meteor3, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(img_meteor3->format, 0, 67, 171));

	// TRANSPARENCIA DE PotatoLaser3000
	SDL_SetColorKey(img_meteor4, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(img_meteor4->format, 0, 67, 171));

	// TRANSPARENCIA DE PotatoLaser3000
	SDL_SetColorKey(laser, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(laser->format, 0, 67, 171));


	/* Posición inicial en pantalla */
	dest.x = 100;
	dest.y = screen->h - imagen->h - 30;
	dest.w = imagen->w;
	dest.h = imagen->h;

	rain.x = rand() % 480;
	rain.y = 0;
	rain.w = imagen->w;
	rain.h = imagen->h;

	rain2.x = rand() % 480;
	rain2.y = 0;
	rain2.w = imagen->w;
	rain2.h = imagen->h;

	rain3.x = rand() % 480;
	rain3.y = 0;
	rain3.w = imagen->w;
	rain3.h = imagen->h;

	rain4.x = rand() % 480;
	rain4.y = 0;
	rain4.w = imagen->w;
	rain4.h = imagen->h;

	laser_rect.x = dest.x;
	laser_rect.y = dest.y;
	laser_rect.w = dest.w;
	laser_rect.h = dest.h;

	datos.asteroid = *img_meteor;
	datos.pantallita = *screen;
	datos.rain = rain;
	//datos.mutex = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_init(&datos.mutex,NULL);

	datos2.asteroid = *img_meteor2;
	datos2.pantallita = *screen;
	datos2.rain = rain2;
	//datos.mutex = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_init(&datos2.mutex,NULL);

	datos3.asteroid = *img_meteor3;
	datos3.pantallita = *screen;
	datos3.rain = rain3;
	//datos.mutex = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_init(&datos3.mutex,NULL);

	datos4.asteroid = *img_meteor4;
	datos4.pantallita = *screen;
	datos4.rain = rain4;
	//datos.mutex = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_init(&datos4.mutex,NULL);

	datos_laser.asteroid = *laser;
	datos_laser.pantallita = *screen;
	datos_laser.laser_rect = laser_rect;
	datos_laser.ship_rect.x = dest.x+27;		// Posiciona el laser.
	datos_laser.ship_rect.y = dest.y;
	//datos.mutex = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_init(&datos_laser.mutex,NULL);


	/* Bucle del juego */
	while(!salir)
	{
		if (num_meteoritos >= 4){
			// Vale, suficientes meteoritos para esquivar.
		} else {
			// Crear Threads.
			// Direccion, Attritubtes, fcunion, argumentos
			if (pthread_create(&thread_id1,NULL,&meteorito_rain1,&datos) != 0)
				printf("Error al crear el Thread1\n");
			if (pthread_create(&thread_id2,NULL,&meteorito_rain2,&datos2) != 0)
				printf("Error al crear el Thread2\n");
			if (pthread_create(&thread_id3,NULL,&meteorito_rain3,&datos3) != 0)
				printf("Error al crear el Thread2\n");
			if (pthread_create(&thread_id4,NULL,&meteorito_rain4,&datos4) != 0)
				printf("Error al crear el Thread2\n");

			num_meteoritos = num_meteoritos + 4;
		}
		
		/* Dibuja la escena */
		pintar(imagen,dest,screen);

		/* Consulta estado teclado */
		teclado = SDL_GetKeyState(NULL);

		/* Cambia estado */
		if(teclado[SDLK_LEFT])
		{
			if(dest.x > 0)
			{
				borrar(screen, dest);
				dest.x -= INC_HORIZONTAL;
			}
		}
		else if(teclado[SDLK_RIGHT])
		{
			if(dest.x < screen->w - imagen->w)
			{
				borrar(screen, dest);
				dest.x += INC_HORIZONTAL;
			}
		} else if (teclado[SDLK_UP]){
			if (dest.y > 20){
				// MOVERSE VERTICALMENTE
				borrar(screen, dest);
				dest.y -= INC_HORIZONTAL;
			}							
		} else if (teclado[SDLK_DOWN]){
			if (dest.y < 430){
				// MOVERSE VERTICALMENTE
				borrar(screen, dest);
				dest.y += INC_HORIZONTAL;
			}
		} else if (teclado[SDLK_SPACE]){
			// Dispara un increible laser mortal que pulveriza cualquier asteoride con forma de patata 
			// que se acerque (SOLO funciona con asteorides con forma de patata, de ahi PotatoLaser3000).


			if (pthread_create(&thread_laser,NULL,&laser_shot,&datos_laser) != 0){
				printf("Error al crear el Thread2\n");
			} else {
				datos_laser.ship_rect.x = dest.x+27;
				datos_laser.ship_rect.y = dest.y;
			}

			if (pthread_join(thread_laser,NULL) != 0){
				printf("Aun no he terminado!\n");
			} else {
			}
			
		}		

		/* Espera la pulsación de una tecla para salir */
		while(SDL_PollEvent(&evento))
		{
			if(evento.type == SDL_KEYDOWN)
				if(evento.key.keysym.sym == SDLK_ESCAPE)
					salir = TRUE;
		}

		if (pthread_join(thread_id1,NULL) != 0){
			printf("Aun no he terminado!\n");
		} else {
			num_meteoritos--;
		}

		if (pthread_join(thread_id2,NULL) != 0){
			printf("Aun no he terminado!\n");
		} else {
			num_meteoritos--;
		}

		if (pthread_join(thread_id3,NULL) != 0){
			printf("Aun no he terminado!\n");
		} else {
			num_meteoritos--;
		}

		if (pthread_join(thread_id4,NULL) != 0){
			printf("Aun no he terminado!\n");
		} else {
			num_meteoritos--;
		}

		// Comprobar Impactos.
		// If Any meteor hits laser beam. Producir Impact FX en Laser.pos
		// Hay que comprobar la HitBox ENTERA. Comprobacion ligera (sin sobrecargar mucho).

		// Meteor 1 Register

		// Meteor 2 Register

		// Meteor 3 Register

		// Meteor 4 Register
		
	}

	/* Libera la superficie */
	SDL_FreeSurface(imagen);

	return 0;
}

void borrar(SDL_Surface *pant, SDL_Rect pos)
{
	/* Borra con el color de fondo el dibujo actual */
	SDL_FillRect(pant, &pos, SDL_MapRGB(pant->format, 0, 0, 0));
}

void pintar(SDL_Surface *img,SDL_Rect pos, SDL_Surface *pant)
{
	SDL_BlitSurface(img, NULL, pant, &pos);	

	/* Se muestra la pantalla screen */
	SDL_Flip(pant);
}

void *meteorito_rain1(void *arg){

	struct datos_t *data = (struct datos_t *) arg;

	if (data->rain.y > 480){
		// Resetear posicion.		
		data->rain.y = -60;
		data->rain.x = rand() % 600;
		//SDL_FillRect(&data->pantallita, &data->rain, SDL_MapRGB(*&data->pantallita.format, 0, 0, 0));
	} else {
		data->rain.y += METEOR1_VELOCITY;
	}	

	pthread_mutex_lock(&data->mutex);	
	SDL_BlitSurface(&data->asteroid, NULL, &data->pantallita, &data->rain);
	/* Se muestra la pantalla screen */
	SDL_Flip(&data->pantallita);
	pthread_mutex_unlock(&data->mutex);
	sched_yield();	// Controlado por Planificador.	
	
	return NULL;
}

void *meteorito_rain2(void *arg){
	
	struct datos_t *data = (struct datos_t *) arg;

	if (data->rain.y > 480){
		// Resetear posicion.
		data->rain.y = -60;
		data->rain.x = rand() % 600;		
		//SDL_FillRect(&data->pantallita, &data->rain, SDL_MapRGB(*&data->pantallita.format, 0, 0, 0));
	} else {
		data->rain.y += METEOR2_VELOCITY;
	}

	pthread_mutex_lock(&data->mutex);	
	SDL_BlitSurface(&data->asteroid, NULL, &data->pantallita, &data->rain);
	/* Se muestra la pantalla screen */
	SDL_Flip(&data->pantallita);
	pthread_mutex_unlock(&data->mutex);
	sched_yield();	// Controlado por Planificador.
	
	return NULL;
}

void *meteorito_rain3(void *arg){
	
	struct datos_t *data = (struct datos_t *) arg;

	if (data->rain.y > 480){
		// Resetear posicion.
		data->rain.y = -60;
		data->rain.x = rand() % 600;		
		//SDL_FillRect(&data->pantallita, &data->rain, SDL_MapRGB(*&data->pantallita.format, 0, 0, 0));
	} else {
		data->rain.y += METEOR3_VELOCITY;
	}

	pthread_mutex_lock(&data->mutex);	
	SDL_BlitSurface(&data->asteroid, NULL, &data->pantallita, &data->rain);
	/* Se muestra la pantalla screen */
	SDL_Flip(&data->pantallita);
	pthread_mutex_unlock(&data->mutex);
	sched_yield();	// Controlado por Planificador.
	
	return NULL;
}

void *meteorito_rain4(void *arg){

	struct datos_t *data = (struct datos_t *) arg;

	if (data->rain.y > 480){
		// Resetear posicion.		
		data->rain.y = -60;
		data->rain.x = rand() % 600;
		SDL_FillRect(&data->pantallita, &data->rain, SDL_MapRGB(*&data->pantallita.format, 0, 0, 0));
	} else {
		data->rain.y += METEOR4_VELOCITY;
	}	

	pthread_mutex_lock(&data->mutex);	
	SDL_BlitSurface(&data->asteroid, NULL, &data->pantallita, &data->rain);
	/* Se muestra la pantalla screen */
	SDL_Flip(&data->pantallita);
	pthread_mutex_unlock(&data->mutex);
	sched_yield();	// Controlado por Planificador.	
	
	return NULL;
}

void *laser_shot(void *arg){

	struct potatolaser_t *data = (struct potatolaser_t *) arg;

	// New Design.
	// While Laser.pox.y > 0 , Laser.pos.y -- then returns.
	// Rereads Pos.x & Pos.y when SpaceBar pressed and Back to Loop.

	/*

	Esto es demasiado rapido, instantaneo. Souspechou que bluquea toudo :V
	while (data->rain.y > 0){
		printf("------ %d\n",data->rain.y);
		pthread_mutex_lock(&data->mutex);
		SDL_BlitSurface(&data->asteroid, NULL, &data->pantallita, &data->rain);	
		SDL_Flip(&data->pantallita);
		data->rain.y--;

		pthread_mutex_unlock(&data->mutex);
		sched_yield();	// Controlado por Planificador.
	}	
	*/
	
	if (data->laser_rect.y <= 0){
		// Resetear posicion.
		// POSICION ACTUAL DE LA NAVE
		data->laser_rect.x = data->ship_rect.x;			
		data->laser_rect.y = data->ship_rect.y;		
		//SDL_FillRect(&data->pantallita, &data->laser_rect, SDL_MapRGB(*&data->pantallita.format, 0, 0, 0));

	} else {
		data->laser_rect.y -= LASER_VELOCITY;
	}

	pthread_mutex_lock(&data->mutex);	
	SDL_BlitSurface(&data->asteroid, NULL, &data->pantallita, &data->laser_rect);
	
	SDL_Flip(&data->pantallita);
	pthread_mutex_unlock(&data->mutex);
	sched_yield();	// Controlado por Planificador.	
	
	return NULL;
}
